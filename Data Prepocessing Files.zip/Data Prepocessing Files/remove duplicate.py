# -*- coding: utf-8 -*-
import pandas as pd
import json
location = ['Syracuse, NY','New York City, NY', 'Rochester, NY', 'Buffalo, NY', \
            'Albany, NY', 'Utica, NY', 'Ithica, NY', 'Binghamton, NY', \
            'Auburn, AL', 'Birmingham, AL', 'Montgomery, AL', 'Atlanta, GA',\
                'Juneau, AK', 'Phoenix, AZ', 'Little Rock, AR', 'Sacramento, CA',\
                'Denver, CO', 'Hartford, CT', 'Dover, DE', 'Tallahassee, FL', \
                'Miami, FL', 'Honolulu, HI', 'Boise, ID', 'Springfield, IL', \
                'Indianapolis, IN', 'Des Moines, IA', 'Topeka, KS', 'Frankfort, KY',\
                'Baton Rouge, LA', 'Augusta, ME', 'Annapolis, MD', 'Boston, MA',\
                'Lansing, MI', 'Detroit, MI', 'St. Paul, MN', 'Jackson, MS', \
                'Jefferson City, MO', 'Helena, MT', 'Washington, DC', 'Lincoln, NE',\
                'Carson City, NV', 'Las Vegas, NV', 'Concord, NH', 'Trenton, NJ', \
                'Newark, NJ', 'Santa Fe, NM', 'Raleigh, NC', 'Charlotte, NC', 'Bismarck, ND',\
                'Columbus, OH', 'Oklahoma City, OK', 'Salem, OR', 'Harrisburg, PA',\
                'Austin, TX', 'Dallas, TX', 'Houston, TX', 'Salt Lake City ,UT',\
                'Olympia, WA', 'Seattle, WA', 'Madison, WI','Cheyenne, WY', 'Los Angeles, CA',\
                'San Fransisco, CA', 'San Jose, CA', 'Madison, WI','Jefferson City, MO']

for loc in location:
    with open ("state data duplicate/"+loc+".json", 'r') as fp:
            df= pd.read_json(fp, lines=True)
    
    df.drop_duplicates(subset="id", keep=False, inplace=True)
    data= df.to_json("state data/"+loc+".json", orient="records", lines=True)
    with open("state data/"+loc+".json", 'a+') as fp1:
        json.dump(data,fp1)
