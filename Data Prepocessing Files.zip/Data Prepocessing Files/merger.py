# -*- coding: utf-8 -*-

import pandas as pd
location = ['Syracuse, NY','New York City, NY', 'Rochester, NY', 'Buffalo, NY', \
            'Albany, NY', 'Utica, NY', 'Ithica, NY', 'Binghamton, NY']
loc= location[0]
with open ("NY/"+loc+".json", 'r') as fp,open ("NY/"+loc+" reviews.json", 'r') as fp1:
        df= pd.read_json(fp, lines=True)
        df1= pd.read_json(fp1, lines=True)
        
dff=pd.concat([df,df1], axis=1, join='inner')